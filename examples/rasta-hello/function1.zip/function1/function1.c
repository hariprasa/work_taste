/* User code: This file will not be overwritten by TASTE. */

#include "function1.h"

void function1_startup()
{
    /* Write your initialization code here,
       but do not make any call to a required interface. */
    printk("funciton1 startup \n");
}

void function1_PI_trigger()
{
    /* Write your code here! */
    printk("Hello World \n");
}

